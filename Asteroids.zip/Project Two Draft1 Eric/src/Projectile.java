import java.awt.*;

public class Projectile {
    public double xpos, ypos;
    public double dx,dy;
    public Rectangle rect;
    public int timer;
    public boolean isAlive = true;
    public Projectile(double xpos, double ypos,double dx, double dy){
        timer = 50;
        this.xpos=xpos;
        this.ypos=ypos;
        this.dx=dx;
        this.dy=dy;
    }
}
