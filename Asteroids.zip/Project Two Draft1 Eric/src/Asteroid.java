import javax.net.ssl.HandshakeCompletedEvent;
import java.awt.*;
import java.util.logging.Handler;

public class Asteroid {
    int xpos;
    int ypos;
    int width;
    int height;
    int lives;
    int dx;
    int dy;
    public boolean isAlive =true;
    public Rectangle rect;
    public Asteroid(int xpos, int ypos, int dx, int dy, int width,int height, boolean isAlive){
        this.xpos=xpos;
        this.ypos=ypos;
        this.dx=dx;
        this.dy=dy;
        lives =3;
        this.width=width;
        this.height = height;

    }

}
