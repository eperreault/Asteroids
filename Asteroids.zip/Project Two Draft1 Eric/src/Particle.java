public class Particle {
    public double xpos;
    public double ypos;
    public double dx;
    public double dy;
    public double width;
    public double height;
    public Particle(double xpos, double ypos,double dx, double dy){

        this.xpos=xpos;
        this.ypos=ypos;
        this.dx =dx;
        this.dy=dy;
        width = 3;
        height = 3;

    }
}
