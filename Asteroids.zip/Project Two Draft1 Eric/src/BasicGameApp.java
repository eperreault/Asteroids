//A and D rotate the thruster clockwise and counterclockwise
//W moves the ship in the opposite direction of the thruster
//Space shoots a bullet in the opposite direction of the thruster
//Eric Perreault 1/28/2021
//Graphics Libraries

import java.awt.Graphics2D;
import java.io.*;
import javax.sound.sampled.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.*;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.*;

//*******************************************************************************
// Class Daefinition Section

public class BasicGameApp implements Runnable, KeyListener {

    //Variable Definition Section
    //Declare the variables used in the program
    //You can set their initial values too

    //Sets the width and height of the program window
    final int WIDTH = 1000;
    final int HEIGHT = 700;


    //Declare the variables needed for the graphics
    public JFrame frame;
    public Canvas canvas;
    public JPanel panel;

    public BufferStrategy bufferStrategy;



    //Declare the objects used in the program
    public Player player;
    public ArrayList<Particle> particles;
    public ArrayList<Asteroid>asteroids;
    public ArrayList<Projectile> projectiles;
    public boolean spacePressed;
    public boolean wPressed;
    public boolean aPressed;
    public boolean dPressed;
    public int deadcounter;
    public int score;
    public int difficulty;
    public boolean makeEnemy;
    public Enemy enemy;
    public Polygon enemyPolygon;
    public ArrayList<EnemyProjectile> enemyProjectiles;
    public int pausetime=-99;
    public int respawntimer=-999;
    //These are things that are made up of more than one variable type




    // Main method definition
    // This is the code that runs first and automatically
    public static void main(String[] args) {
        BasicGameApp ex = new BasicGameApp();   //creates a new instance of the game
        new Thread(ex).start();                 //creates a threads & starts up the code in the run( ) method
    }


    // Constructor Method
    // This has the same name as the class
    // This section is the setup portion of the program
    // Initialize your variables and construct your program objects here.
    public BasicGameApp() {

        setUpGraphics();
        canvas.addKeyListener(this);
        System.out.println("Setting up game");
        player = new Player(500,350);
        particles = new ArrayList<>();
        asteroids = new ArrayList<>();
        projectiles = new ArrayList<>();
        enemyProjectiles = new ArrayList<>();
        enemy= new Enemy(WIDTH, (int) (HEIGHT/2+(Math.random()*300-150)),0,0);
        int[] enemyXPoints = {enemy.xpos,enemy.xpos-50, enemy.xpos+50};
        int[] enemyYPoints = {enemy.ypos,enemy.ypos-50, enemy.ypos+50};
        enemyPolygon = new Polygon(enemyXPoints,enemyYPoints,3);
        makeAsteroids();
        makeEnemies();
        //variable and objects
        //create (construct) the objects needed for the game and load up

        render();


    }// BasicGameApp()
    public void playSound(String name){

        try{
            File soundFile = new File(name);
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
        }
        catch (UnsupportedAudioFileException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        catch (LineUnavailableException e){
            e.printStackTrace();
        }
    }

//*******************************************************************************
//User Method Section
//
// put your code to do things here.

    // main thread
    // this is the code that plays the game after you set things up
    public void run() {
        while(true)
        {
            render();
            makeEnemies();
            moveEnemy();
            movePlayer();
            moveProjectiles();
            thrusterParticles();
            moveAsteroids();
            checkIntersections();
            System.out.println(enemy.xpos);
            pause(10);

        }

    }

    //paints things on the screen using bufferStrategy
    public void render() {

        Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, WIDTH, HEIGHT);
        g.setColor(Color.BLACK);
        g.fillRect(0,0,1000,700);
        g.setColor(Color.white);
        if(player.isAlive) {
            g.drawOval((int) player.xpos, (int) player.ypos, player.width, player.height);
            g.fillOval((int) player.thrusterXpos, (int) player.thrusterYpos, 7, 7);
        }
        //g.drawOval((int)player.shooterXpos,(int)player.shooterYpos,7,7);
        if(player.isAlive) {
            for (Particle particle : particles) {
                g.fillRect((int) particle.xpos, (int) particle.ypos, (int) particle.width, (int) particle.height);
            }
        }
        for(Asteroid asteroid:asteroids){
            if(asteroid.isAlive==true) {
                 g.drawOval(asteroid.xpos, asteroid.ypos, asteroid.width, asteroid.height);
            }
        }
        for(Projectile projectile:projectiles){
            if (projectile.isAlive) {
                g.fillOval((int) projectile.xpos, (int) projectile.ypos, 3, 3);
            }

        }
        g.drawString(""+score,50,50 );
        g.setColor(Color.red);
        if (enemy.isAlive){
        g.fillPolygon(enemyPolygon);}
        for(EnemyProjectile enemyProjectile:enemyProjectiles){
            g.fillOval((int)enemyProjectile.xpos,(int)enemyProjectile.ypos,3,3);
        }




        g.dispose();

        bufferStrategy.show();
    }

    //Pauses or sleeps the computer for the amount specified in milliseconds
    public void pause(int time) {
        //sleep
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {

        }
    }

    //Graphics setup method
    private void setUpGraphics() {
        frame = new JFrame("My First Game");   //Create the program window or frame.  Names it.

        panel = (JPanel) frame.getContentPane();  //sets up a JPanel which is what goes in the frame
        panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));  //sizes the JPanel
        panel.setLayout(null);   //set the layout

        // creates a canvas which is a blank rectangular area of the screen onto which the application can draw
        // and trap input events (Mouse and Keyboard events)
        canvas = new Canvas();
        canvas.setBounds(0, 0, WIDTH, HEIGHT);
        canvas.setIgnoreRepaint(true);

        panel.add(canvas);  // adds the canvas to the panel.

        // frame operations
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //makes the frame close and exit nicely
        frame.pack();  //adjusts the frame and its contents so the sizes are at their default or larger
        frame.setResizable(false);   //makes it so the frame cannot be resized
        frame.setVisible(true);      //IMPORTANT!!!  if the frame is not set to visible it will not appear on the screen!

        // sets up things so the screen displays images nicely.
        canvas.createBufferStrategy(2);
        bufferStrategy = canvas.getBufferStrategy();
        canvas.requestFocus();
        System.out.println("DONE graphic setup");

    }
    public void movePlayer(){
        player.centerX=player.xpos+player.width/2;
        player.centerY=player.ypos+player.height/2;
        player.thrusterXpos=player.centerX+(Math.cos(player.angle)*35)-3.7;
        player.thrusterYpos=player.centerY+(Math.sin(player.angle)*35)-3.7;
        player.shooterXpos=player.centerX+(Math.cos(player.angle+Math.PI)*35)-3.7;
        player.shooterYpos=player.centerY+(Math.sin(player.angle+Math.PI)*35)-3.7;
        if(aPressed){
            player.angle+=.1;

        }
        if(dPressed){
            player.angle-=.1;
        }
        if(wPressed){
            if(player.dx<8&&player.dx>-8) {
                player.dx += (Math.cos(player.angle) * .08);
            }
            if(player.dy<8&&player.dy>-8) {
                player.dy += (Math.sin(player.angle) * .08);
            }
            if(player.dx>0){
                player.dx-=.01;
            }
            if(player.dx<0){
                player.dx+=.01;
            }
            if(player.dy>0){
                player.dy-=.01;
            }
            if(player.dy<0){
                player.dy+=.01;
            }
        }
        if(!wPressed){
            if(player.dx>0){
                player.dx-=.05;
            }
            if(player.dx<0){
                player.dx+=.05;
            }
            if(player.dy>0){
                player.dy-=.05;
            }
            if(player.dy<0){
                player.dy+=.05;
            }
             }
        if(player.xpos+player.width<0){
            player.xpos=WIDTH;
        }
        if(player.xpos>WIDTH){
            player.xpos=0-player.width;
        }
        if(player.ypos+player.height<0){
            player.ypos=HEIGHT;
        }
        if(player.ypos>HEIGHT){
            player.ypos=0-player.height;
        }
        if(spacePressed==true){
            fireProjectile();
            spacePressed=false;
        }
        player.xpos-=player.dx;
        player.ypos-=player.dy;

        player.rect = new Rectangle((int)player.xpos,(int)player.ypos,player.width,player.height);
        if(!player.isAlive)player.rect = new Rectangle(-100,0,0,0);

    }
    public void thrusterParticles(){
        if(wPressed){
            double thrusterdx=player.dx;
            double thrusterdy = player.dy;

            particles.add(new Particle(player.thrusterXpos+3.5,player.thrusterYpos+3.5,thrusterdx+(1.5*Math.random()-.75),thrusterdy+(1.5*Math.random()-.75)));
        }
        for(Particle particle:particles){
            particle.xpos+=particle.dx;
            particle.ypos+=particle.dy;
        }
        for(Particle particle:particles){
            particle.width-=.05;
            particle.height-=.05;

        }
    }
    public void makeAsteroids(){
        for(int i = 1; i<=3+difficulty;i++) {
            int xpos;
            int ypos;
            if (Math.random() > .5) {
                xpos = (int) Math.random() * 200;
            } else {
                xpos = (int) Math.random() * 200 + 800;
            }
            if (Math.random() > .5) {
                ypos = (int) Math.random() * 200;
            } else {
                ypos = (int) Math.random() * 200 + 800;
            }
              
                asteroids.add(new Asteroid(xpos, ypos, (int) ((Math.random() * 7 - 3)), (int) ((Math.random() * 7 - 3)), 100 - difficulty * 3, 100 - difficulty * 3,true));

        }

        for(int i = 0; i<asteroids.size();i++){
            if(asteroids.get(i).dx==0){
                asteroids.get(i).dx++;
            }
            if(asteroids.get(i).dy==0){
                asteroids.get(i).dy++;
            }

        }
    }
    public void moveAsteroids(){ 
        for(int i =0;i<asteroids.size();i++) {
            asteroids.get(i).xpos += asteroids.get(i).dx;
            asteroids.get(i).ypos += asteroids.get(i).dy;
            if (asteroids.get(i).xpos + asteroids.get(i).width < 0) {
                asteroids.get(i).xpos = 1000;
            }
            if (asteroids.get(i).xpos > 1000) {
                asteroids.get(i).xpos = 0-asteroids.get(i).width;
            }
            if (asteroids.get(i).ypos + asteroids.get(i).height < 0) {
                asteroids.get(i).ypos = 700;

            }
            if (asteroids.get(i).ypos > 700) {
                asteroids.get(i).ypos = 0-asteroids.get(i).height;
            }


        }
        if(allGone()){
            asteroids.clear();
            makeAsteroids();
            System.out.println(asteroids.size()+"!");
        }
    }
    public void fireProjectile(){
        if(player.isAlive) {
            projectiles.add(new Projectile(player.centerX + (Math.cos(player.angle + Math.PI) * 35) - .2,
                    player.centerY + (Math.sin(player.angle + Math.PI) * 35) - .2,
                    Math.cos(player.angle) * 7 + player.dx, Math.sin(player.angle) * 10));
        }
    }
    public void moveProjectiles(){
        for(Projectile projectile:projectiles){

            projectile.xpos-=projectile.dx;
            projectile.ypos-=projectile.dy;
            projectile.rect = new Rectangle((int)projectile.xpos,(int)projectile.ypos,3,3);
            projectile.timer--;
            if(projectile.xpos<=0){
                projectile.xpos=WIDTH;
            }
            if (projectile.xpos>WIDTH){
                projectile.xpos=0;
            }
            if(projectile.ypos<=0){
                projectile.ypos=HEIGHT;
            }
            if (projectile.ypos>HEIGHT){
                projectile.ypos=0;
            }
            if(projectile.timer==0){

                projectile.isAlive=false;
            }

            if (!projectile.isAlive){
                projectile.rect=new Rectangle(-1,-1,0,0);
            }

        }
        for(EnemyProjectile projectile:enemyProjectiles){
        projectile.xpos-=projectile.dx;
        projectile.ypos-=projectile.dy;

        projectile.rect = new Rectangle((int)projectile.xpos,(int)projectile.ypos,3,3);

        projectile.timer--;
        if(projectile.timer==0){

            projectile.isAlive=false;
        }

        if (!projectile.isAlive){
            projectile.rect=new Rectangle(-1,-1,0,0);
        }}

    }
    public void checkIntersections(){

        for(int i =0; i<asteroids.size();i++){
            if(asteroids.get(i).isAlive){
                asteroids.get(i).rect = new Rectangle(asteroids.get(i).xpos,asteroids.get(i).ypos,asteroids.get(i).width,asteroids.get(i).height);
            }
            if(!asteroids.get(i).isAlive){
                asteroids.get(i).rect = new Rectangle(0,0,0,0);
            }
            if (asteroids.get(i).rect.intersects(player.rect)){
                player.isAlive = false;
                playSound("Junk Crash 04 (1).wav");

                playSound("Junk Crash 04 (1).wav");


            }
            for(Projectile projectile:projectiles){
                if(projectile.rect.intersects(asteroids.get(i).rect)){
                    asteroids.get(i).isAlive=false;
                    projectile.isAlive=false;
                }
            }
            for(EnemyProjectile enemyProjectile:enemyProjectiles){
                if (enemyProjectile.rect.intersects(player.rect)){
                    player.isAlive=false;
                }
            }
            for(Projectile projectile:projectiles){
                if(projectile.rect.intersects(enemyPolygon.getBounds())) {
                    enemy.isAlive = false;
                    enemy.xpos = WIDTH;
                    enemy.ypos = (int) (HEIGHT/2+(Math.random()*300)-150);
                }
            }
        }
    }
    public boolean allGone(){
        deadcounter=0;
        for(int i =0;i<asteroids.size();i++){
            if(!asteroids.get(i).isAlive){
                deadcounter++;


            }
        }
        if(deadcounter==asteroids.size()){
            if(difficulty<2) {
                difficulty++;

            }
            score+=100;
            return true;
        }
        else{
            return false;
        }
    }
    public void makeEnemies(){
        if(score>300&&!enemy.isAlive){
            if(respawntimer<-1000){
            makeEnemy=true;
            respawntimer=0;
            }
            respawntimer--;
        }        if(makeEnemy){
            enemy.isAlive=true;
            enemy.dx=-3;
            enemy.dy=0;
            makeEnemy=false;
        }
    }
    public void moveEnemy(){
        if(enemy.isAlive) {
            enemy.xpos += enemy.dx;
            enemy.ypos += enemy.dy;
            if(pausetime<-100&&enemy.isAlive){
                enemyProjectiles.add(new EnemyProjectile(enemy.xpos, enemy.ypos + 8, (enemy.xpos - player.xpos) / 40, (enemy.ypos - player.ypos) / 40));
                pausetime=0;
            }pausetime--;

        }
        int[] enemyXPoints = {enemy.xpos,enemy.xpos-17, enemy.xpos+17};
        int[] enemyYPoints = {enemy.ypos,enemy.ypos+25, enemy.ypos+25};
        enemyPolygon = new Polygon(enemyXPoints,enemyYPoints,3);
        if(enemy.xpos<WIDTH/2&&enemy.stop){
            enemy.dx=0;



            }

    }
    @Override
    public void keyTyped(KeyEvent e){

        int key = e.getKeyChar();
    }
    @Override

    public void keyReleased(KeyEvent e){
        int key = e.getKeyCode();
        if(key==KeyEvent.VK_SPACE){
            spacePressed= false;
        }
        if(key==KeyEvent.VK_W){
            wPressed=false;
        }
        if(key==KeyEvent.VK_A){
            aPressed=false;

        }
        if(key==KeyEvent.VK_D){
            dPressed=false;
        }
    }
    @Override

    public void keyPressed(KeyEvent e) {

        int key = e.getKeyCode();
        if(key==KeyEvent.VK_SPACE){
            spacePressed = true;
        }
        if(key==KeyEvent.VK_W){
            wPressed=true;
        }
        if(key==KeyEvent.VK_A){
            aPressed=true;

        }
        if(key==KeyEvent.VK_D){
            dPressed=true;
        }


    }



}