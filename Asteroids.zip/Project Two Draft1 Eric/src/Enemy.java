import java.awt.*;
public class Enemy {
    public int xpos;
    public int ypos;
    public boolean isAlive;
    public int dx;
    public int dy;
    public Rectangle rect;
    public boolean stop;
    public Enemy(int xpos, int ypos, int dx, int dy){
        this.xpos = xpos;
        this.ypos = ypos;
        this.dx = dx;
        this.dy = dy;
        stop = true;

    }}
