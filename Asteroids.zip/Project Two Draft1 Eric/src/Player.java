import java.awt.*;
import java.lang.Math;
public class Player {

    public double xpos;
    public double ypos;
    public int width;
    public int height;
    public double angle;
    public double dx;
    public double dy;
    public double thrusterXpos;
    public double thrusterYpos;
    public double shooterXpos;
    public double shooterYpos;
    public double centerX;
    public double centerY;
    public Rectangle rect;
    public boolean isAlive = true;

    public Player(int xpos, int ypos){
        this.xpos=xpos;
        this.ypos=ypos;
        width=50;
        height=50;
        angle=0;
        dx=0;
        dy=0;



    }

}
